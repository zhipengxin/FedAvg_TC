# -*- coding: UTF-8 -*- #
"""
@filename:splitpcap.py
@author:XinZhipeng
@time:2024-07-30
"""
import os


def splitCap(exepath, read_file=None, write_dir=None):
    # input='F:\\DataSet\\iptas_tbps_drop\\豆瓣\\1\\2024-01-04-15-39-29\\python.exe.pcap'  # test
    # output='F:\\DataSet\\iptas_tbps_drop\\豆瓣\\1'
    # print(os.getcwd())  #获取当前目录
    os.chdir(exepath)  # 跳转到.exe文件目录
    splitcap_cmd = '".\\SplitCap.exe -r "' + read_file + '" -s session"' + '" -o "' + write_dir  # + '" -port 443"'  # cmd命令行
    splitcap_cmd = '"' + splitcap_cmd + '"'
    splitcap_cmd = '"' + splitcap_cmd + '"'
    print(splitcap_cmd)
    os.system(splitcap_cmd)


if __name__ == '__main__':
    #  splitcap.exe文件位置
    exe_path = "D:\\Project\\Pythonproject\\Sub-FedAvg-main\\src\\utils"

    # 1.批量打开文件目录
    # dataset_path = 'F:\\DataSet\\iptas_tbps_drop'
    # dirlists = os.listdir(dataset_path)
    # for dirlist in dirlists:
    #     app_path = dataset_path + '\\' + dirlist
    #     applists = os.listdir(app_path)
    #     for applist in applists:
    #         drop_path = app_path + '\\' + applist
    #         droplits = os.listdir(drop_path)
    #         for droplist in droplits:
    #             input_file = drop_path + '\\' + droplist + '\\python.exe.pcap'
    #             output_dir = drop_path
    #             # print(input_file)
    #             # print(output_dir)
    #             splitCap(exe_path, input_file, output_dir)  # 执行分流

    #  2.单个处理
    # input_file = "D:\\Document\\SEU\Packet\\A3C\\2024-01-26-23-04-58\\msedge.exe.pcap"
    # output_dir = "D:\\Document\\SEU\Packet\\A3C\\1"
    # splitCap(exe_path, input_file, output_dir)

    # 3.小批量处理
    output_dir = "D:\\Project\\Pythonproject\\Sub-FedAvg-main\\data\\VPN"
    dir = "D:\\Project\\Pythonproject\\Sub-FedAvg-main\\data\\VPN-PCAPS-01"
    lists = os.listdir(dir)
    # print(lists)
    for list in lists:
        input_file = dir + '\\' + list
        # print(input_file)
        # print(output_dir)
        splitCap(exe_path, input_file, output_dir)
    print("splitCap has been done!")

    # splitCap()  # test
