# -*- coding: UTF-8 -*- #
"""
@filename:pcappng2pcap.py
@author:XinZhipeng
@time:2024-07-30
"""
import os
import subprocess

# from TrafficFlowClassification.TrafficLog.setLog import logger
'''
editcap.exe 的用法, 
==> editcap.exe -F libpcap -T ether file.pcapng file.pcap
==> 需要将 editcap.exe 所在的路径 (C:/Program Files/Wireshark) 添加在环境目录中
'''


def pcapng_to_pcap(path):
    """将文件夹 path 中所有的 pcapng 文件转换为 pcap 文件

    Args:
        path (str): pcapng 文件所在的路径
    """
    for files in os.listdir(path):
        if files.split('.')[1] == 'pcapng':
            # pcapng2pcap = 'editcap.exe -F libpcap -T ether {}{} {}{}.pcap'.format(path, files, path, files.split('.')[0])
            # os.system(pcapng2pcap) # 直行 cmd 命令
            output_pcap_name = '{}.pcap'.format(files.split('.')[0])
            prog = subprocess.Popen(["D:\\QMDownload\\WireShark\\editcap.exe",
                                     "-F", "libpcap",
                                     "-T", "ether",
                                     os.path.abspath(os.path.join(path, files)),
                                     os.path.abspath(os.path.join(path, output_pcap_name))],
                                    stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
            _, _ = prog.communicate()
            os.remove(os.path.abspath(os.path.join(path, files)))  # pcapng 转换之后, 源文件删除


if __name__ == "__main__":
    pcapng_to_pcap(r"D:\Project\Pythonproject\Sub-FedAvg-main\data\NonVPN-PCAPs-01")
    print("pcappng2pcap is done!")
