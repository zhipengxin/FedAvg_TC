# -*- coding: UTF-8 -*- #
"""
@filename:test_util.py
@author:XinZhipeng
@time:2024-07-18
"""
num_classes=10
num_shards_test_per_class=20
idx_class = [i for i in range(num_classes)]
idx_shards_test_y = {j: [i for i in range(num_shards_test_per_class)] for j in range(num_classes)}
print(f"idx_class:{idx_class}")
print(f"idx_shards_test_y:{idx_shards_test_y}")